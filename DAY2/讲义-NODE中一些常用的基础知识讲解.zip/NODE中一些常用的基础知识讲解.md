##NODE中一些常用的基础知识讲解
@(201712)

###NODE的特点
> 常人所说的NODE是后台编程语言，这种说法其实是错误的。NODE只是一个工具（或者环境），我们可以把NODE安装在服务器上，NODE提供的环境可以运行JS代码，这样我们就可以在服务器端使用JavaScript编写一些处理服务器相关操作的程序，也可以理解为JS变为了后台编程语言。
>  
> 1、NODE是基于V8引擎来渲染JS的（V8是谷歌的引擎）
> - 渲染JS的速度会很快
> - 我们在使用JS开发后台程序的时候，不需要考虑浏览器兼容了，使用JS的最新标准即可（ECMAScript）
>  
> 2、单线程、无阻塞I/O操作、事件驱动（event-driven）

---
`NODE是如何执行JS代码的`
> 常用的方式有三种
> - 使用NODE的REPL（Read-Evaluate-Print-Loop，输入-求值-输出-循环）命令
> - 使用命令行：node xxx.js （在命令行中把xxx.js文件中的代码执行）
> - 在webStorm中直接右键 -> Run xxx.js  也可以把JS代码在NODE中执行
> - ...
![Alt text](./1514090312846.png)
![Alt text](./1514090839802.png)
![Alt text](./1514091187413.png)

---
`I/O操作`
> I（input）：输入
> O（output）：输出
> I/O操作泛指对文件及文件中内容的操作（包括：增删改查）
>  
> JS作为前端编程语言（运行在客户端浏览器中），不能直接对客户端的本地文件进行I/O操作
> - 目的是为了保证客户端信息的安全
> - 有一些机制可以操作客户端内容（input type='file'），但是需要用户手动选择某些文件上传才可以
>  
> JS作为后台编程语言（运行在服务器端NODE环境下），可以对服务器上的资源文件进行I/O操作
> - NODE中绝对提供了供JS代码操作I/O的方法（后面讲到的fs模块就是做这件事情的）
```javascript
let fs = require('fs');
//=>异步读取：异步读取文件中的内容就是无阻塞I/O操作
//fs.readFile()

//=>同步读取
let con = fs.readFileSync('./readme.md', 'utf8');
console.log(con);
```